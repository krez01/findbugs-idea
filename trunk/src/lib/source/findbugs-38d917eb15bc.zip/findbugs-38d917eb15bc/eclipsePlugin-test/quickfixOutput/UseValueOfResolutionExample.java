public class UseValueOfResolutionExample {
    public Boolean getBoolean(boolean value) {
        return Boolean.valueOf(value);
    }

    public Integer getInteger(int value) {
        return Integer.valueOf(value);
    }
}
