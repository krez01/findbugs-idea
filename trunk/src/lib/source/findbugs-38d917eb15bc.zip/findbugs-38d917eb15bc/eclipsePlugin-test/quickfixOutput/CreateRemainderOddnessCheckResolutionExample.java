public class CreateRemainderOddnessCheckResolutionExample {
    public boolean isOdd(int value) {
        return value % 2 != 0;
    }
}
