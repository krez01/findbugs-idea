public class MakeInnerTypeStaticResolutionExample {
    class InnerType {
    }
}
