class Finalize {
    @Override
    protected void finalize() {
    }
}
