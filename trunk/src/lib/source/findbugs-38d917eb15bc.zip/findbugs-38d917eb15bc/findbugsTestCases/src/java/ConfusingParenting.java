public final class ConfusingParenting {
    protected int a;

    protected Object b;
}
