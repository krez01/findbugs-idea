import edu.umd.cs.findbugs.annotations.SuppressWarnings;

@SuppressWarnings("HE")
public class TestSuppressWarnings {

    @Override
    public boolean equals(Object o) {
        return this == o;
    }
}
