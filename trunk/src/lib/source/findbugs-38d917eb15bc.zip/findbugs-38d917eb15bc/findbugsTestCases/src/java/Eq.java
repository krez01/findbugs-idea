abstract class Eq {
    abstract public boolean equals(Eq q);
}
