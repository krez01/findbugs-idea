public class SelfAssignment {
    public int foo() {
        int x = 3;
        x = x;
        return x;
    }
}
