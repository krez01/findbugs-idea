
public class hashCODEnoEQUALS {

    /**
     * @param args
     */

    int ReuVeN;

    int MOJOJOJO;// FIXME!! Amazing, this isn't bad naming procedure

    public static void main(String[] args) {

    }

    @Override
    public int hashCode() {
        return 189234712;
    }
}
