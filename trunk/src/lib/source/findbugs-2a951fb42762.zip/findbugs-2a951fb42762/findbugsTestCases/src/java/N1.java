public class N1 {
    public void mincemeat() {
    }
}
