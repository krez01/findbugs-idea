
public class Parent {
    @Override
    public boolean equals(Object o) {
        return false;
    }

    public void blargh() {

    }
}
