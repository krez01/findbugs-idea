public interface I2 {
    public void i2();
}
