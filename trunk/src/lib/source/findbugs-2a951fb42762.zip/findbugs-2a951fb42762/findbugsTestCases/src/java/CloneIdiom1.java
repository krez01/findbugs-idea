class CloneIdiom1 implements Cloneable {
}
