class UnreadFields {
    int x = 1;
}
