class StringEqualityTest {

    boolean almostEmpty(String s) {
        return s.trim() == "";
    }
}
